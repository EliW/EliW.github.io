<?php
function my_set_cookie($name, $value, $timeout = 3600) {
    $domain = $_SERVER['HTTP_HOST'];
    $https = !empty($_SERVER['HTTPS']);
    $name = md5("security.{$name}");
    setcookie($name, $value, $timeout, '/', $domain, $https, true);
}

function my_read_cookie($name) {
    $name = md5("security.{$name}");
    return isset($_COOKIE[$name]) ? $_COOKIE[$name] : NULL;
}
