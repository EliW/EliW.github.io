<?php
if (isset($_REQUEST['search'])):
?>

<p>No results found for: <?= $_REQUEST['search'] ?>!</p>

<?php endif; ?>

<form method="POST" action="">
    <label>Search our website: <input name="search" /></label>
    <input type="submit">
</form>
