<?php
require 'lib/db.php';
$user = 'oscarm';

if (isset($_POST['realname'])) {
    // Save the updates to this user:
    $query = db()->prepare("UPDATE users SET realname = ? WHERE username = ?");
    $query->execute([$_POST['realname'], $user]);
    echo "<p>Your real name has been updated!</p>";
}
?>
<form method="POST" action="">
    <label>
        Updating Real Name for user: <?= $user ?><br />
        <input name="realname" />
    </label><br />
    <input type="submit">
</form>
