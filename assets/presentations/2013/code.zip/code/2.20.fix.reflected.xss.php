<html>
<head><title>Beta Website</title></head>
<body>
    <header>Account</header>
    <h1>Thanks for visiting our website</h1>
    <?php if (!count($_POST)): ?>
        <h2>Please let us know if you are interesting Beta Access:</h2>
        <form method="POST" action="">
            <label>Name: <input name="name" /></label>
            <label>Email: <input name="email" type="email" /></label>
            <label>Permission to Contact?
                <input name="contact" type="checkbox" value="yes" /></label>
            <input type="submit">
        </form>
    <?php else: ?>
        <h2>Thank you for your submission!</h2>
        <p>We have received the following submission and will contact 
           you when our website is ready:</p>
        <ul>
            <li>Name: <?= $_POST['name'] ?></li>
            <li>Email: <?= $_POST['email'] ?></li>
            <li>Permission: <?= $_POST['contact'] ?: 'No' ?></li>
            <li>IP: <?= $_SERVER['REMOTE_ADDR'] ?></li>
            <li>Browser: <?= $_SERVER['HTTP_USER_AGENT'] ?></li>
        </ul>
    <?php endif; ?>
</body>    
</html>
