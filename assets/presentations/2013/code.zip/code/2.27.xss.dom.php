<script src="lib/jquery-2.0.3.min.js"></script>
<script>
$(document).ready(function() {
    $('#verify').submit(function() {
        $('#thanks').remove();
        var first = $(this).find("input[name=first]").val();
        $("<p id=\"thanks\">Thanks for the submission: " + first + "</p>")
            .hide().css('color', 'red').insertAfter($('#message')).fadeIn();
        return false;
        });
});
</script>

<p id="message">Please let us know who you are:</p>
<form id="verify">
<label>First: <input name="first" /></label><br />
<label>Last: <input name="last" /></label><br />
<input type="submit" name="submit" />
</form>