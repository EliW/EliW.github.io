<h3>Security Code Examples</h3>
<?php
// Also set some cookies for us for future:
setcookie('session', md5(rand()));

$dir = new DirectoryIterator('.');
foreach ($dir as $file): if (preg_match("/^\d+/", $file)):
?>
<a href="<?= $file ?>"><?= $file ?></a><br />
<?php endif; endforeach; ?>