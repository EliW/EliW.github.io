<?php
class User {
    private function _hashPassword($password)
    {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        return $hash;
    }

    public function checkPassword($password)
    {
        return password_verify($password, $this->password);
    }

    public function save()
    {
        // If our password has changed, then hash it:
        if ($this->changed('password')) {
            $this->password = $this->_hashPassword($this->password);
        }

        $saved = parent::save();
        return $saved;
    }

    public function generateForgotCode()
    {
        $code = hash('sha1', uniqid(rand(), TRUE));
        $this->forgot = $code;
        $this->save();
        return $code;
    }

    private function tokenRememberMe($user) {
        $agent = $_SERVER['HTTP_USER_AGENT'];
        return implode('|', [$user->id, $user->username, $user->password, $agent]);
    }

    private function hashRememberMe($user) {
        return password_hash(tokenRememberMe($user), PASSWORD_DEFAULT);
    }

    private function setRememberMe($user) {
        $length = 7776000; /* 3 months */
        setcookie('Memory', $user->id . '|' . hashRememberMe($user), time()+$length);
    }

    public function checkRememberMe() {
        if (empty($_SESSION['user_id']) && ($memory = Cookie::get('Memory'))) {
            list($id, $hash) = explode('|', $memory);
            $success = FALSE;
            if ($id) {
                try {
                    $this->load($id); // Load the user:
                    if (password_verify(tokenRememberMe($user), $hash)) {
                        $success = TRUE;
                    }
                } catch (Exception $e) {}
            }

            if ($success) {
                /* Login User */
                $this->login();
            } else { 
                setcookie('Memory', 0, time()-172800);
            }
        }
    }
}