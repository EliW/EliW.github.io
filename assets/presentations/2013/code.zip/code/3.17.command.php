<?php
if (isset($_POST['year'])) {
    // Process the year's stats and return:
    $count = `grep -c {$_POST['year']} ./data/access.short.log`;
?>

<p>Stats are: <?= $count ?></p>
<a href="">Clear</a>

<?php } else { ?>

<p>What Year do you want stats from?</p>
<form method="POST" action="">
    <label>Year: <input name="year" /></label>
    <input type="submit">
</form>

<?php } ?>
