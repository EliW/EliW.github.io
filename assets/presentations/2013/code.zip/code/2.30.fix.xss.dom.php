<html>
<head><title>Eli's Account</title></head>
<body>
    <h1><strong>User</strong>: EliW</h1>
    <ul>
        <li>Name: <span class="editable">Eli White</span></li>
        <li>Company: <span class="editable">musketeers.me</span></li>
    </ul>
<script src="lib/jquery-2.0.3.min.js"></script>
<script>
$(document).ready(function() {
    $('ul').on('click', '.editable', function() {
        console.log(this);
        var $orig = $(this);
        var $input = $('<input />').val($orig.text());
        $input.on('blur keydown', function(e) {
            if (!e.keyCode || (e.keyCode == 13)) {
                var $input = $(this);
                var val = $input.val();
                $input.replaceWith('<span class="editable">'+val+'</span>');
            }
        });
        $orig.replaceWith($input);
    });
});
</script>
</body>
</html>
