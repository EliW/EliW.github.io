<pre>
<?php
// One way hashes:
$password = "MyVoiceIsMyPassport";

// Simple salt:
$salt = "PHP FOR LIFE";
$hash = hash('sha512', $salt . $password);
echo $hash, "\n";

// More fancy & Unique
$salt = hash('md5', uniqid(rand(), TRUE));
$hash = $salt . hash('sha512', $salt . $password);
echo $hash, "\n";

?>