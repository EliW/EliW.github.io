<?php
error_reporting(-1);
ini_set('display_errors', 1);
