<?php
// Mock User Class
class User extends stdClass {
    public function save() {}
}