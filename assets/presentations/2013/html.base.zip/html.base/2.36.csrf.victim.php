<?php
require 'lib/user.php';

if (!empty($_POST['newpass'])) {
    if ($user = new User($_SESSION['user'])) {
        $user->password = $_POST['newpass'];
        $user->save();
        echo "Password Changed Successfully!";
    }
}
?>