<pre>
<?php
// One way hashes:
$str = "This is my secret data";

echo md5($str), "\n";
echo sha1($str), "\n";

// Moving to more advanced requires 'hash' method:
echo hash('sha256', $str), "\n";
echo hash('sha512', $str), "\n";
echo hash('whirlpool', $str), "\n";

// Find all available algorithms:
//var_dump(hash_algos());

?>