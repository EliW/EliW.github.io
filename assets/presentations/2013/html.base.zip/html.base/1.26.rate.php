<?php
$blocked = false;
if (!isset($_SESSION['attempts'])) {
    $_SESSION['attempts'] = [];
}
$now = new DateTime();
if (count($_SESSION['attempts']) > 4) {
    $oldest = new DateTime($attempts[0]);
    if ($oldest->modify('+5 minute') > $now) {
        $blocked = true; // Block them
    }
}
if (!$blocked && $user->login()) {
    unset($_SESSION['attempts']);
} else {
    array_unshift($_SESSION['attempts'], $now->format(DateTime::ISO8601));
    $_SESSION['attempts'] = array_slice($_SESSION['attempts'], 0, 5);
}
