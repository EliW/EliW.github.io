use test;

create table users (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `realname` varchar(100) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

insert into users (username, realname, password) values
   ('admin', 'Admin User', md5('blah')),
   ('eliw', 'Eli White', md5('asdfasdf')),
   ('omerida', 'Oscar Merida', md5('iowefiewf')),
   ('sandys1', 'Sandy Smith', md5('asdfklweklf'));

