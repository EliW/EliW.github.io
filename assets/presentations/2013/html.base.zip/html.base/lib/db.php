<?php
function db() {
    return $connection = new PDO(
        'mysql:host=mysql;port=3306;dbname=security;charset=utf8',
        'security', 'securitytest');
}
