<?php
require 'lib/db.php';
$user = NULL;

if (isset($_POST['user']) && isset($_POST['pass'])):
    // Try to log the user in:
    $results = db()->query(
        "SELECT *
         FROM users 
         WHERE username = '{$_POST['user']}'
            AND password = sha1('{$_POST['pass']}')");
    $user = $results->fetchObject();

    if ($user):
?>

    <p>Welcome back <?= $user->realname ?> (<?= $user->username ?>)!</p>
    <a href="">Logout</a>
    
    <?php else: ?>
    
    <p style="color:red">Error Logging In!</p>
    
    <?php endif; ?>
<?php endif; ?>

<?php if (!$user): ?>
<p>Please Log In:</p>
<form method="POST" action="">
    <label>Username: <input name="user" /></label><br />
    <label>Password: <input name="pass" type="password"/></label><br />
    <input type="submit">
</form>
<?php endif; ?>
