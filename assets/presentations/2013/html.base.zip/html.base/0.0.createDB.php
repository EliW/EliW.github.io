<?php
require 'lib/db.php';
$db = db();

$result = $db->exec("
drop table if exists users;
");

if ($result === FALSE) { die(print_r($db->errorInfo(), true)); }

$result = $db->exec("
create table users (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `realname` varchar(100) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
");

if ($result === FALSE) { die(print_r($db->errorInfo(), true)); }

$result = $db->exec("
insert into users (username, realname, password) values
   ('admin', 'Admin User', md5('blah')),
   ('eliw', 'Eli White', md5('asdfasdf')),
   ('omerida', 'Oscar Merida', md5('iowefiewf')),
   ('sandys1', 'Sandy Smith', md5('asdfklweklf'));
");

if ($result === FALSE) { die(print_r($db->errorInfo(), true)); }

echo "Database Successfully Refreshed";
