<?php
require 'lib/db.php';
$user = 'oscarm';

$query = db()->prepare("SELECT * FROM users WHERE username = ?");
$query->execute([$user]);
$user = $query->fetchObject();
?>

<p>Welcome to <?= $user->realname ?>'s Profile Page</p>
