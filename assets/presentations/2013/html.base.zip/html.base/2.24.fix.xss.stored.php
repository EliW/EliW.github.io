<html>
<head><title>My Website - <?= $page ?></title></head>
<body>
    <header class="<?= ($page == 'account') ?: 'active' ?>">
        Account (<?= $user->username ?>)
    </header>
    <h1>Welcome to <?= $user->fullname ?>'s Account</h1>
    <img src="<?= $user->headshot ?>" />
    <p><strong>BIO:</strong> <?= $user->bio ?></p>
    <p><strong>Latest Post:</strong> <?= $user->lastPost(); ?></p>
</body>

