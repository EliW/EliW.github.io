<?php
if (isset($_POST['type']) && isset($_POST['id'])):
    $type = $_POST['type'];
    $id = $_POST['id'];
    $results = db()->query(
        "SELECT *
         FROM {$type} 
         WHERE id = {$_POST['id']}
         ");
    $data = $results->fetchObject();
}
